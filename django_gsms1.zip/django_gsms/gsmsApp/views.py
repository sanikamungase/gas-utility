from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from .models import ServiceRequest
from .forms import ServiceRequestForm
from .models import UserProfile
from .forms import UserProfileForm

@login_required
def submit_request(request):
    if request.method == 'POST':
        form = ServiceRequestForm(request.POST)
        if form.is_valid():
            service_request = form.save(commit=False)
            service_request.customer = request.user
            service_request.save()
            return redirect('request_tracking')
    else:
        form = ServiceRequestForm()
    return render(request, 'services/submit_request.html', {'form': form})

@login_required
def request_tracking(request):
    service_requests = ServiceRequest.objects.filter(customer=request.user)
    return render(request, 'services/request_tracking.html', {'service_requests': service_requests})

def home(request):
    # Add any logic needed for your home page
    return render(request, 'home.html')

def custom_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'login.html', {'form': form, 'error_message': 'Invalid username or password.'})
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def account_info(request):
    user_profile, created = UserProfile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=user_profile)
        if form.is_valid():
            form.save()
            return redirect('account_info')
    else:
        form = UserProfileForm(instance=user_profile)
    
    return render(request, 'account_info.html', {'form': form})

def support_home(request):
    requests = ServiceRequest.objects.all()
    return render(request, 'support_home.html', {'requests': requests})

def update_request(request, request_id):
    request = ServiceRequest.objects.get(pk=request_id)
    if request.status == 'Resolved':
        return redirect('support_home')  # Prevent updating resolved requests
    if request.assigned_representative != request.user:
        return redirect('support_home')  # Prevent unauthorized access
    if request.method == 'POST':
        # Update request details and/or status
        # Redirect to support_home or specific request detail page
        return render(request, 'update_request.html', {'request': request})