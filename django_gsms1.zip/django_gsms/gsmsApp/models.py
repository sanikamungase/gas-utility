from django.db import models
from django.contrib.auth.models import User


class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    address = models.CharField(max_length=255, blank=True)

class ServiceRequest(models.Model):
    PENDING = 'Pending'
    IN_PROGRESS = 'In Progress'
    RESOLVED = 'Resolved'
    REQUEST_STATUS_CHOICES = [
        (PENDING, 'Pending'),
        (IN_PROGRESS, 'In Progress'),
        (RESOLVED, 'Resolved'),
    ]

    request_type = models.CharField(max_length=100)
    request_details = models.TextField()
    status = models.CharField(max_length=20, choices=REQUEST_STATUS_CHOICES, default=PENDING)
    submitted_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    customer = models.ForeignKey(User, on_delete=models.CASCADE)
    attachment = models.FileField(upload_to='attachments/', null=True, blank=True)

    
    def __str__(self):
        return f'{self.request_type} - {self.customer.username}'
