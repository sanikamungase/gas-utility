from django.urls import path
from gsmsApp import views

from django.contrib import admin
from django.urls import path, include  # Include the include function

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.custom_login, name='login'),
    path('submit_request/', views.submit_request, name='submit_request'),
    path('request_tracking/', views.request_tracking, name='request_tracking'),
    path('admin/', admin.site.urls),
    path('account_info/', views.account_info, name='account_info'),
    path('support_home/', views.support_home, name='support_home'),
    path('accounts/', include('django.contrib.auth.urls')),  # Include authentication URLs
]
