from django import forms
from .models import ServiceRequest
from .models import UserProfile

class ServiceRequestForm(forms.ModelForm):
    class Meta:
        model = ServiceRequest
        fields = ['request_type', 'request_details', 'attachment']

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['address'] 